# CS2223 HW 1: Double Trouble
User: Kang Zhang
How to run game: Use main.java to run the game
