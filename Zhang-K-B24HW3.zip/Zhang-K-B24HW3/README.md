# CS2223
# Run all files seperately as they all contain main.


Notes:
- When inputing a list, seperate each number with a comma. 
- I run the the brute force inversion check to make sure bubble and merge sort match the number of inversion 




