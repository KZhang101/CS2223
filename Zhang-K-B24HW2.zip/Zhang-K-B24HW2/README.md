# CS2223
# Run Zhang_K_Lucas_stuff_B24HW2 and Zhang_K_Subirach_stuff_B24HW2 separately. 
Run Zhang_K_Lucas_stuff_B24HW2 and Zhang_K_Subirach_stuff_B24HW2 separately. 
There will be inputs guiding you through each step, ensuring which function is being implemented.


Notes for Lucas stuff:
The order of growth is exponential and is approaching the golden ratio. 

Notes for Subirach:
The largest combination is the r = n/2, combinations: 12870
The most common sum was 66, which is exactly half of the max sum (132) 
